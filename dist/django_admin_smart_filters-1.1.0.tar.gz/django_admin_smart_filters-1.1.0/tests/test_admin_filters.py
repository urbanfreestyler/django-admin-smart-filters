from __future__ import annotations

from pathlib import Path

import django
import pytest
from django.conf import settings
from django.contrib import admin
from django.contrib.admin.sites import AdminSite
from django.db import models
from django.test import RequestFactory

from django_admin_smart_filters.builder import Filter
from django_admin_smart_filters.declarations import DropdownFilter
from django_admin_smart_filters.theme import ThemeAdapter


if not settings.configured:
    settings.configure(
        SECRET_KEY="test-key",
        DEFAULT_CHARSET="utf-8",
        INSTALLED_APPS=[
            "django.contrib.admin",
            "django.contrib.auth",
            "django.contrib.contenttypes",
            "django.contrib.sessions",
        ],
        DATABASES={"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": ":memory:"}},
        MIDDLEWARE=[],
        ROOT_URLCONF=__name__,
        TEMPLATES=[
            {
                "BACKEND": "django.template.backends.django.DjangoTemplates",
                "APP_DIRS": True,
                "DIRS": [
                    str(Path(__file__).resolve().parents[1] / "django_admin_smart_filters" / "templates")
                ],
            }
        ],
    )

django.setup()


class AdminFilterTestModel(models.Model):
    status = models.CharField(max_length=50)
    category = models.CharField(max_length=50)
    assignee = models.CharField(max_length=50, blank=True)
    created = models.DateField(null=True)
    score = models.FloatField(null=True)
    active = models.BooleanField(default=False)

    class Meta:
        app_label = "tests"


class RecordingQuerySet:
    def __init__(self, calls: list[dict[str, object]] | None = None) -> None:
        self.calls = calls or []

    def filter(self, **kwargs: object) -> "RecordingQuerySet":
        return RecordingQuerySet(self.calls + [kwargs])


class _BaseSmartAdmin(admin.ModelAdmin):
    def get_smart_filter_base_queryset(self, request):
        return RecordingQuerySet()

    def changelist_view(self, request, extra_context=None):
        return extra_context or {}


def _admin_class(declarations):
    from django_admin_smart_filters.admin import SmartFilterAdminMixin

    class TestAdmin(SmartFilterAdminMixin, _BaseSmartAdmin):
        smart_filters = declarations

    return TestAdmin


def _make_admin(declarations):
    admin_class = _admin_class(declarations)
    return admin_class(AdminFilterTestModel, AdminSite())


def _all_filter_declarations():
    return [
        DropdownFilter("status"),
        Filter.field("category").multi_select(),
        Filter.field("created").date_range(),
        Filter.field("score").numeric_range(),
        Filter.field("active").boolean_toggle(),
        Filter.field("assignee").autocomplete(),
    ]


@pytest.mark.parametrize(
    ("data", "expected_calls"),
    [
        ({"status": "open"}, [{"status": "open"}]),
        ({"category__in": ["a", "b"]}, [{"category__in": ["a", "b"]}]),
        (
            {"created_start": "2026-01-01", "created_end": "2026-01-31"},
            [{"created__gte": "2026-01-01"}, {"created__lte": "2026-01-31"}],
        ),
        ({"score_min": "10", "score_max": "20"}, [{"score__gte": 10.0}, {"score__lte": 20.0}]),
        ({"active": "true"}, [{"active": True}]),
    ],
)
def test_each_built_in_kind_filters_queryset_from_get_params(data, expected_calls) -> None:
    admin_instance = _make_admin(_all_filter_declarations())
    request = RequestFactory().get("/admin/tests/adminfiltertestmodel/", data=data)

    queryset = admin_instance.get_queryset(request)

    assert queryset.calls == expected_calls


def test_class_style_and_fluent_declarations_share_normalization_path() -> None:
    class_style_admin = _make_admin([
        DropdownFilter("status"),
        DropdownFilter("category", alias="cat"),
    ])
    fluent_admin = _make_admin([
        Filter.field("status").dropdown(),
        Filter.field("category").as_alias("cat").dropdown(),
    ])

    class_specs = class_style_admin.get_smart_filter_specs()
    fluent_specs = fluent_admin.get_smart_filter_specs()

    assert class_specs == fluent_specs


def test_default_admin_usage_requires_no_changelist_replacement() -> None:
    admin_instance = _make_admin(_all_filter_declarations())

    assert admin_instance.change_list_template == "admin/change_list.html"


def test_changelist_context_includes_all_five_filter_kinds_and_templates() -> None:
    admin_instance = _make_admin(_all_filter_declarations())
    request = RequestFactory().get("/admin/tests/adminfiltertestmodel/", data={"status": "open"})

    context = admin_instance.changelist_view(request)

    assert context["smart_filter_controls_template"] == "admin/django_admin_smart_filters/theme/default/filter_controls.html"
    assert context["smart_filter_active_bar_template"] == "admin/django_admin_smart_filters/theme/default/active_filters_bar.html"

    # Verify that the new change_list.html template is being picked up
    admin_instance = _make_admin(_all_filter_declarations())
    assert admin_instance.change_list_template == "admin/change_list.html"

    controls = context["filter_controls"]
    assert len(controls) == 6
    assert {control["kind"] for control in controls} == {
        "dropdown",
        "multi_select",
        "date_range",
        "numeric_range",
        "boolean_toggle",
        "autocomplete",
    }


def test_autocomplete_control_context_includes_endpoint_and_page_metadata() -> None:
    admin_instance = _make_admin(_all_filter_declarations())
    request = RequestFactory().get("/admin/tests/adminfiltertestmodel/")

    context = admin_instance.changelist_view(request)
    autocomplete_control = next(control for control in context["filter_controls"] if control["kind"] == "autocomplete")

    assert autocomplete_control["endpoint_url"].endswith("/smart-filters/autocomplete/")
    assert autocomplete_control["min_query_length"] == 2
    assert autocomplete_control["page_size"] == 20
    assert autocomplete_control["options"] == []


def test_changelist_context_exposes_chip_state_and_reset_url() -> None:
    admin_instance = _make_admin(_all_filter_declarations())
    request = RequestFactory().get(
        "/admin/tests/adminfiltertestmodel/",
        data={"status": "open", "category__in": ["alpha", "beta"], "page": "2"},
    )

    context = admin_instance.changelist_view(request)

    chip_labels = [chip["label"] for chip in context["active_filter_chips"]]
    assert chip_labels == ["Status: open", "Category: alpha", "Category: beta"]
    assert context["reset_all_url"] == "?page=2"


def test_active_bar_html_renders_remove_links_and_reset_control() -> None:
    admin_instance = _make_admin(_all_filter_declarations())
    request = RequestFactory().get(
        "/admin/tests/adminfiltertestmodel/",
        data={"status": "open", "category__in": ["alpha", "beta"], "page": "3"},
    )

    context = admin_instance.changelist_view(request)
    html = context["smart_filter_active_bar_html"]

    assert "Reset all filters" in html
    assert "Status: open" in html
    assert "Category: alpha" in html
    assert "Category: beta" in html
    assert "?category__in=beta&amp;page=3&amp;status=open" in html


def test_theme_adapter_changes_render_templates_without_changing_query_semantics() -> None:
    class AdapterAdmin(_admin_class(_all_filter_declarations())):
        smart_filter_theme_adapter = ThemeAdapter(
            name="compat",
            controls_template="admin/django_admin_smart_filters/filter_controls.html",
            active_bar_template="admin/django_admin_smart_filters/active_filters_bar.html",
        )

    admin_instance = AdapterAdmin(AdminFilterTestModel, AdminSite())
    request = RequestFactory().get("/admin/tests/adminfiltertestmodel/", data={"status": "open"})

    queryset = admin_instance.get_queryset(request)
    context = admin_instance.changelist_view(request)

    assert queryset.calls == [{"status": "open"}]
    assert context["smart_filter_theme_adapter"] == "compat"
    assert context["smart_filter_controls_template"] == "admin/django_admin_smart_filters/filter_controls.html"
    assert context["smart_filter_active_bar_template"] == "admin/django_admin_smart_filters/active_filters_bar.html"
